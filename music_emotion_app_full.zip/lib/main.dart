import 'package:flutter/material.dart';

void main() {
  runApp(MusicEmotionApp());
}

class MusicEmotionApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Music Emotion App',
      theme: ThemeData(primarySwatch: Colors.deepPurple),
      home: HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('🎵 Music Emotion AI'),
      ),
      body: Center(
        child: ElevatedButton(
          onPressed: () {
            // Placeholder for audio analysis
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text('Analyzing music...'))
            );
          },
          child: Text('Upload a music file'),
        ),
      ),
    );
  }
}
