import 'package:flutter/material.dart';

void main() => runApp(EmotionBeatApp());

class EmotionBeatApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'EmotionBeat',
      theme: ThemeData.light(),
      darkTheme: ThemeData.dark(),
      themeMode: ThemeMode.system,
      home: Scaffold(
        appBar: AppBar(title: Text("EmotionBeat")),
        body: Center(child: Text("Welcome to EmotionBeat!")),
      ),
    );
  }
}