package com.example.emotion_music_ai

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}