import 'package:flutter/material.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});

  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  String displayName = 'کاربر عزیز';
  String selectedTheme = 'تم شب';
  bool notificationsEnabled = true;

  final List<String> availableThemes = ['تم شب', 'تم رنگی روشن', 'تم اقیانوسی'];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('تنظیمات حساب')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          TextField(
            decoration: const InputDecoration(
              labelText: 'نام نمایشی',
              border: OutlineInputBorder(),
            ),
            onChanged: (val) => setState(() => displayName = val),
          ),
          const SizedBox(height: 20),
          DropdownButtonFormField<String>(
            value: selectedTheme,
            items: availableThemes
                .map((theme) => DropdownMenuItem(
                      value: theme,
                      child: Text(theme),
                    ))
                .toList(),
            onChanged: (val) => setState(() => selectedTheme = val!),
            decoration: const InputDecoration(
              labelText: 'پوسته انتخابی',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 20),
          SwitchListTile(
            value: notificationsEnabled,
            onChanged: (val) => setState(() => notificationsEnabled = val),
            title: const Text('اعلان‌ها فعال باشند'),
          ),
          const SizedBox(height: 30),
          ElevatedButton.icon(
            icon: const Icon(Icons.save),
            label: const Text('ذخیره تنظیمات'),
            onPressed: () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('تنظیمات ذخیره شد')),
              );
            },
          ),
        ],
      ),
    );
  }
}