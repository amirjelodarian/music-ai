import 'package:flutter/material.dart';

class HomePage extends StatelessWidget {
  final String userName = "کاربر عزیز";

  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.deepPurple[800],
      appBar: AppBar(
        backgroundColor: Colors.deepPurple[900],
        title: Text("سلام، \$userName"),
        actions: [
          IconButton(
            icon: const Icon(Icons.settings),
            onPressed: () => Navigator.pushNamed(context, '/settings'),
          )
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              "حالت‌های موسیقی پیشنهادی",
              style: TextStyle(color: Colors.white70, fontSize: 18),
            ),
            const SizedBox(height: 10),
            Expanded(
              child: ListView(
                scrollDirection: Axis.horizontal,
                children: [
                  musicCard("Chill", Icons.self_improvement, Colors.lightBlue),
                  musicCard("Focus", Icons.psychology, Colors.deepPurpleAccent),
                  musicCard("Workout", Icons.fitness_center, Colors.redAccent),
                  musicCard("Dance", Icons.directions_run, Colors.orangeAccent),
                ],
              ),
            ),
            const SizedBox(height: 20),
            const Text(
              "دستاوردهای شما",
              style: TextStyle(color: Colors.white70, fontSize: 18),
            ),
            const SizedBox(height: 10),
            Expanded(
              child: ListView(
                children: [
                  achievementCard("آرام‌ترین هفته", "۷ روز بدون احساس منفی"),
                  achievementCard("پرشورترین روز", "بیشترین شادی ثبت شده"),
                  achievementCard("ضبط‌کننده حرفه‌ای", "۱۰ بار تحلیل صدا"),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget musicCard(String title, IconData icon, Color color) {
    return Container(
      width: 140,
      margin: const EdgeInsets.only(right: 12),
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(20),
      ),
      padding: const EdgeInsets.all(16),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, color: Colors.white, size: 48),
          const SizedBox(height: 10),
          Text(title,
              style:
                  const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }

  Widget achievementCard(String title, String desc) {
    return Card(
      color: Colors.deepPurple[700],
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      margin: const EdgeInsets.symmetric(vertical: 8),
      child: ListTile(
        title:
            Text(title, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        subtitle: Text(desc, style: const TextStyle(color: Colors.white70)),
        leading: const Icon(Icons.emoji_events, color: Colors.amberAccent),
      ),
    );
  }
}